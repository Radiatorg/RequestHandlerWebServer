package com.vodchyts.backend.feature.dto;

public record UserInfoResponse(String login, String role) {}
