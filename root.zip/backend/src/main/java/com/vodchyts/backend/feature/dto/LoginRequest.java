package com.vodchyts.backend.feature.dto;

public record LoginRequest(String login, String password) {}
