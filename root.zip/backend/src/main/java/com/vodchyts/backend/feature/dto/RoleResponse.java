package com.vodchyts.backend.feature.dto;

public record RoleResponse(Integer roleID, String roleName) {}