package com.vodchyts.backend.feature.dto;

public record RegisterRequest(String login, String password, String roleName) {}

