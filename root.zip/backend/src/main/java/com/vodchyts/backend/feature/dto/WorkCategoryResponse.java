package com.vodchyts.backend.feature.dto;

public record WorkCategoryResponse(
        Integer workCategoryID,
        String workCategoryName,
        long requestCount
) {}