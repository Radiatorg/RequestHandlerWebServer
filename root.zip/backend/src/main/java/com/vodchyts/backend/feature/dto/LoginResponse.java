package com.vodchyts.backend.feature.dto;

public record LoginResponse(String accessToken) {}
