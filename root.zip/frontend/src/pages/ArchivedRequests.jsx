import React from 'react';
import Requests from './Requests';

export default function ArchivedRequests() {
    return <Requests archived={true} />;
}